file(REMOVE_RECURSE
  "CMakeFiles/sysy.dir/src/sylib.c.o"
  "libsysy.a"
  "libsysy.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/sysy.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

file(REMOVE_RECURSE
  "libsysy.a"
)

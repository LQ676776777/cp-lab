# CMake generated Testfile for 
# Source directory: /home/wwb/compiler_new/carrotcompiler/runtime
# Build directory: /home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/runtime
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.

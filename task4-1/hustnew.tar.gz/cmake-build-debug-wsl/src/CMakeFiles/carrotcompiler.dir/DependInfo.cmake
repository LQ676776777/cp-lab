# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/wwb/compiler_new/carrotcompiler/src/main.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/CMakeFiles/carrotcompiler.dir/main.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "../include"
  "../src/utils"
  "../src/parser"
  "../src/ir"
  "../src/opt"
  "../src/riscv"
  "../src/checker"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/utils/CMakeFiles/utils.dir/DependInfo.cmake"
  "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/parser/CMakeFiles/parser.dir/DependInfo.cmake"
  "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/ir/CMakeFiles/ir.dir/DependInfo.cmake"
  "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/opt/CMakeFiles/opt.dir/DependInfo.cmake"
  "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/riscv/CMakeFiles/riscv.dir/DependInfo.cmake"
  "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/checker/CMakeFiles/checker.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

file(REMOVE_RECURSE
  "../compiler"
  "../compiler.pdb"
  "CMakeFiles/carrotcompiler.dir/main.cpp.o"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/carrotcompiler.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

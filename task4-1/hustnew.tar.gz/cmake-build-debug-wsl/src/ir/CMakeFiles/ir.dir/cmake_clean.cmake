file(REMOVE_RECURSE
  "CMakeFiles/ir.dir/genIR.cpp.o"
  "CMakeFiles/ir.dir/ir.cpp.o"
  "libir.a"
  "libir.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/ir.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

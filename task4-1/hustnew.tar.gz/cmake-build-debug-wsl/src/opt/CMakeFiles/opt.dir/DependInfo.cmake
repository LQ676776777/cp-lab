# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/wwb/compiler_new/carrotcompiler/src/opt/BasicOperation.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/opt/CMakeFiles/opt.dir/BasicOperation.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/opt/CombineInstr.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/opt/CMakeFiles/opt.dir/CombineInstr.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/opt/ConstSpread.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/opt/CMakeFiles/opt.dir/ConstSpread.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/opt/DeleteDeadCode.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/opt/CMakeFiles/opt.dir/DeleteDeadCode.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/opt/LoopInvariant.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/opt/CMakeFiles/opt.dir/LoopInvariant.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/opt/SimplifyJump.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/opt/CMakeFiles/opt.dir/SimplifyJump.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/opt/opt.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/opt/CMakeFiles/opt.dir/opt.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "../include"
  "../src/ir"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/ir/CMakeFiles/ir.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

file(REMOVE_RECURSE
  "CMakeFiles/opt.dir/BasicOperation.cpp.o"
  "CMakeFiles/opt.dir/CombineInstr.cpp.o"
  "CMakeFiles/opt.dir/ConstSpread.cpp.o"
  "CMakeFiles/opt.dir/DeleteDeadCode.cpp.o"
  "CMakeFiles/opt.dir/LoopInvariant.cpp.o"
  "CMakeFiles/opt.dir/SimplifyJump.cpp.o"
  "CMakeFiles/opt.dir/opt.cpp.o"
  "libopt.a"
  "libopt.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/opt.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

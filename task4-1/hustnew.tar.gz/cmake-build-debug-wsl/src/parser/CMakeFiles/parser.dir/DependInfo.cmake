# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/wwb/compiler_new/carrotcompiler/src/parser/ast.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/parser/CMakeFiles/parser.dir/ast.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/parser/parser.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/parser/CMakeFiles/parser.dir/parser.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/parser/tokens.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/parser/CMakeFiles/parser.dir/tokens.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "../include"
  "../src/parser"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

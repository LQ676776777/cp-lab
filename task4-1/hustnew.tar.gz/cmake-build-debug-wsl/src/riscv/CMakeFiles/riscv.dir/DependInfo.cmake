# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/home/wwb/compiler_new/carrotcompiler/src/riscv/backend.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/riscv/CMakeFiles/riscv.dir/backend.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/riscv/instruction.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/riscv/CMakeFiles/riscv.dir/instruction.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/riscv/optimize.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/riscv/CMakeFiles/riscv.dir/optimize.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/riscv/regalloc.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/riscv/CMakeFiles/riscv.dir/regalloc.cpp.o"
  "/home/wwb/compiler_new/carrotcompiler/src/riscv/riscv.cpp" "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/riscv/CMakeFiles/riscv.dir/riscv.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "../include"
  "../src/ir"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/src/ir/CMakeFiles/ir.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")

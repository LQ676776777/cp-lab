file(REMOVE_RECURSE
  "CMakeFiles/riscv.dir/backend.cpp.o"
  "CMakeFiles/riscv.dir/instruction.cpp.o"
  "CMakeFiles/riscv.dir/optimize.cpp.o"
  "CMakeFiles/riscv.dir/regalloc.cpp.o"
  "CMakeFiles/riscv.dir/riscv.cpp.o"
  "libriscv.a"
  "libriscv.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/riscv.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()

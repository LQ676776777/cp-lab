# CMake generated Testfile for 
# Source directory: /home/wwb/compiler_new/carrotcompiler/test
# Build directory: /home/wwb/compiler_new/carrotcompiler/cmake-build-debug-wsl/test
# 
# This file includes the relevant testing commands required for 
# testing this directory and lists subdirectories to be tested as well.

#include "checker.h"

/* 静态语义分析
 1. Redefined Variable 重复定义变量/重复声明 ok
 2. Redefined Function 函数形参重复定义  ok
 3. Redefined Function 函数重复定义 ok
 4. Use Undefined Variable 使用未定义变量 ok
 5. Use Undefined Function 使用未定义函数 ok
 6. Can not Match Function Parameters 函数参数/类型不匹配
*/
void Checker::visit(CompUnitAST &ast) {
  make_new_table();
  for (auto &decl : ast.declDefList) {
    decl->accept(*this);
  }
}

void Checker::visit(DeclDefAST &ast) {
  if (ast.Decl) {
    ast.Decl->accept(*this);
  }
  if (ast.funcDef) {
    ast.funcDef->accept(*this);
  }
}

void Checker::visit(DeclAST &ast) {
  for (auto &def : ast.defList) {
    def->accept(*this);
  }
  // 将定义的变量插入符号表
  //printf("insert var %s\n", ast.defList[0]->id->c_str());
  if (!InsertVar(ast)) {
    // TODO ERROR
    exit(1);
  }
}

void Checker::visit(DefAST &ast) {
  if (ast.initVal) {
    ast.initVal->accept(*this);
  }
}

void Checker::visit(InitValAST &ast) {
  if (ast.exp) {
    ast.exp->accept(*this);
  } else {
    for (auto &initVal: ast.initValList) {
      initVal->accept(*this);
    }
  }
}

void Checker::visit(FuncFParamAST &ast) {
  for (auto &exp : ast.arrays) {
    if (exp) {
      exp->accept(*this);
    }
  }
}
void Checker::visit(ReturnStmtAST &ast) {
  if(ast.exp) {
    ast.exp->accept(*this);
  }
}

void Checker::visit(FuncDefAST &ast) {
  // 将函数插入符号表
  if (!InsertFunc(ast)) {
    // TODO ERROR
    char *err_msg = new char[50];
    sprintf(err_msg, "Redefined Function \"%s\".", ast.id->c_str());
    err.error(err_msg);
    delete[] err_msg;
    exit(1);
  }
  start_of_new_func = true;
  ast.block->accept(*this);
}

void Checker::visit(BlockAST &ast) {
  //一个新的函数在插入时就已经建了新的符号表，这里不用重复建
  if (start_of_new_func)
    start_of_new_func = false;
  //对非函数定义的语句块添加新的符号表
  else
    make_new_table();

  for (auto &item : ast.blockItemList) {
    item->accept(*this);
  }

  //语句块作用域结束，删除之前添加的符号表
  delete_table();
}

void Checker::visit(BlockItemAST &ast) {
  if (ast.stmt) {
    ast.stmt->accept(*this);
  }
  if (ast.decl) {
    ast.decl->accept(*this);
  }
}

void Checker::visit(StmtAST &ast) {
  if (ast.returnStmt) {
    ast.returnStmt->accept(*this);
  }
  if (ast.selectStmt) {
    ast.selectStmt->accept(*this);
  }
  if (ast.block) {
    ast.block->accept(*this);
  }
  if (ast.exp) {
    ast.exp->accept(*this);
  }
  if (ast.lVal) {
    ast.lVal->accept(*this);
  }
}

void Checker::visit(SelectStmtAST &ast) {
  if (ast.elseStmt) {
    ast.elseStmt->accept(*this);
  }
  if (ast.ifStmt) {
    ast.ifStmt->accept(*this);
  }
  if (ast.cond) {
    ast.cond->accept(*this);
  }
}

void Checker::visit(IterationStmtAST &ast) {
  if (ast.cond) {
    ast.cond->accept(*this);
  }
  if (ast.stmt) {
    ast.stmt->accept(*this);
  }
}

void Checker::visit(AddExpAST &ast) {
  if (ast.addExp) {
    ast.addExp->accept(*this);
  }
  if (ast.mulExp) {
    ast.mulExp->accept(*this);
  }
}

void Checker::visit(MulExpAST &ast) {
  if (ast.mulExp) {
    ast.mulExp->accept(*this);
  }
  if (ast.unaryExp) {
    ast.unaryExp->accept(*this);
  }
}

void Checker::visit(UnaryExpAST &ast) {
  if (ast.primaryExp) {
    ast.primaryExp->accept(*this);
  }
  if (ast.unaryExp) {
    ast.unaryExp->accept(*this);
  }
  if (ast.call) {
    ast.call->accept(*this);
  }
}

void Checker::visit(PrimaryExpAST &ast) {
  if (ast.exp) {
    ast.exp->accept(*this);
  }
  if (ast.lval) {
    ast.lval->accept(*this);
  }
  if (ast.number) {
    ast.number->accept(*this);
  }
}

void Checker::visit(LValAST &ast) {
  for (auto &exp : ast.arrays) {
    if (exp) {
      exp->accept(*this);
    }
  }
  auto str = ast.id.get();
  Entry *entry = Lookup(*str);
  if (entry == nullptr) {
    // TODO ERROR
    char *err_msg = new char[50];
    sprintf(err_msg, "Use Undefined Variable \"%s\".", ast.id->c_str());
    err.error(err_msg);
    delete[] err_msg;
    exit(1);
  }
  this->current_type.type = entry->type;
  this->Expr_int = (entry->type == TYPE::TYPE_INT);
}

void Checker::visit(NumberAST &ast) {
  this->Expr_int = ast.isInt;
  this->current_type.type = ast.isInt ? TYPE::TYPE_INT : TYPE::TYPE_FLOAT;
}

void Checker::visit(CallAST &ast) {
  //特殊函数不做处理
  if (!ast.id->compare("getint") ||
      !ast.id->compare("getfloat") ||
      !ast.id->compare("getch")  ||
      !ast.id->compare("getarray") ||
      !ast.id->compare("get_float_array") ||
      !ast.id->compare("putint") ||
      !ast.id->compare("putfloat") ||
      !ast.id->compare("putch") ||
      !ast.id->compare("putarray") ||
      !ast.id->compare("put_float_array")) {
    //::printf("call name = %s\n", ast.id->c_str());
    return;
  }
  Entry *entry = Lookup(*ast.id);
  if (entry == nullptr) {
    // TODO ERROR
    char *err_msg = new char[50];
    sprintf(err_msg, "Use Undefined Function \"%s\".", ast.id->c_str());
    err.error(err_msg);
    delete[] err_msg;
    exit(1);

  } else {
    //参数长度不匹配
    //printf("call name = %s\n", ast.id->c_str());
    //printf("entry->func_params.size() = %d, ast.funcCParamList.size() = %d\n", entry->func_params.size(), ast.funcCParamList.size());
    if (entry->func_params.size() != ast.funcCParamList.size()) {
      // TODO ERROR
      char *err_msg = new char[50];
      sprintf(err_msg, "Can not Match Function Parameters \"%s\".", ast.id->c_str());
      err.error(err_msg);
      delete[] err_msg;
      exit(1);

    } else {
      //遍历实参与形参
      int i = 0;
      for (auto &exp : ast.funcCParamList) {
        exp->accept(*this);
        if (this->current_type.type != entry->func_params[i].type) {
          // TODO ERROR
          char *err_msg = new char[50];
          sprintf(err_msg, "Can not Match Function Parameters \"%s\".", ast.id->c_str());
          err.error(err_msg);
          delete[] err_msg;
          exit(1);

        } else {
          i++;
        }
      }
    }
    this->current_type.type = entry->type;
    this->Expr_int = (entry->type == TYPE::TYPE_INT);
  }
}

void Checker::visit(RelExpAST &ast) {
  if (ast.relExp) {
    ast.relExp->accept(*this);
  }
  if (ast.addExp) {
    ast.addExp->accept(*this);
  }
  this->Expr_int = false;
  this->current_type.type = TYPE::TYPE_BOOL;
}

void Checker::visit(EqExpAST &ast) {
  if (ast.eqExp) {
    ast.eqExp->accept(*this);
  }
  if (ast.relExp) {
    ast.relExp->accept(*this);
  }
  this->Expr_int = false;
  this->current_type.type = TYPE::TYPE_BOOL;
}

void Checker::visit(LAndExpAST &ast) {
  if (ast.lAndExp) {
    ast.lAndExp->accept(*this);
  }
  if (ast.eqExp) {
    ast.eqExp->accept(*this);
  }
  // TODO ????
}

void Checker::visit(LOrExpAST &ast) {
  if (ast.lOrExp) {
    ast.lOrExp->accept(*this);
  }
  if (ast.lAndExp) {
    ast.lAndExp->accept(*this);
  }
  // TODO ????
}

#include "errorReporter.h"

ErrorReporter::ErrorReporter(std::ostream &error_stream) : err(error_stream) {}

void ErrorReporter::error(const std::string &msg) {
  std::cerr << "Error: " << msg << std::endl;
}

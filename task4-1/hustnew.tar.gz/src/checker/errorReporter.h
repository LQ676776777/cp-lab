#ifndef CARROTCOMPILER_ERRORREPORTER_H
#define CARROTCOMPILER_ERRORREPORTER_H

#include <iostream>

class ErrorReporter {
public:
  explicit ErrorReporter(std::ostream &error_stream);

  void error(const std::string &msg);
private:
  std::ostream &err;
};


#endif // CARROTCOMPILER_ERRORREPORTER_H
